package tzchoice.kisanga.joshua.amplifier.adapter;

/**
 * Created by user on 4/2/2017.
 */

public class SearchAdapter {
}
