package tzchoice.kisanga.joshua.amplifier.app;

/**
 * Created by user on 4/2/2017.
 */

public class Constatnts {
    public final static String  browserKey = "AIzaSyBOxtd6JsWAyj53EPio4CZE5YpDOLTcsUc";
    public final static String  ayo_playlist_id = "PL6EUerhQbkP2r65jcGdN7QOYXr3jxbYCS";
    public final static String  diamond_playlist_id = "UUev-b-xy-p5fHK8x3zJyn1Q";

    public final static String  KEY_SEARCH_QUERY = "search_query";
    public final static String  KEY_VIDEO_ID = "VIDEO_ID";
    public final static String  KEY_VIDEO_TITLE = "VIDEO_TITLE";
    public final static String  KEY_VIDEO_DESC = "VIDEO_DESC";
    public final static String  KEY_VIDEO_DATE = "VIDEO_DATE";
    public final static String  KEY_VIDEO_DOWNLOAD_LINK = "VIDEO_LINK";


    // global topic to receive app wide push notifications
    public static final String TOPIC_GLOBAL = "global";

    // broadcast receiver intent filters
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";

    // id to handle the notification in the notification tray
    public static final int NOTIFICATION_ID = 100;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;

    public static final String SHARED_PREF = "ah_firebase";
}
