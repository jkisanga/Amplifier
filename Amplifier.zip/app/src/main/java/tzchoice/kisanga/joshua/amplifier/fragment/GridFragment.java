package tzchoice.kisanga.joshua.amplifier.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.squareup.okhttp.OkHttpClient;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.realm.Realm;
import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Response;
import retrofit.Retrofit;
import tzchoice.kisanga.joshua.amplifier.R;
import tzchoice.kisanga.joshua.amplifier.adapter.ChannelAdapter;
import tzchoice.kisanga.joshua.amplifier.app.AutoFitGridLayoutManager;
import tzchoice.kisanga.joshua.amplifier.app.Config;
import tzchoice.kisanga.joshua.amplifier.pojo.Channel;
import tzchoice.kisanga.joshua.amplifier.retrofit.IRetrofit;
import tzchoice.kisanga.joshua.amplifier.table.RChannel;

/**
 * A simple {@link Fragment} subclass.
 */
public class GridFragment extends Fragment {
    private RecyclerView recyclerView;
    private LinearLayoutManager lLayout;
    private Realm realm;
    private List<RChannel> rChannels = new ArrayList<>();
    private ChannelAdapter channelAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_grid, container, false);
       // this.realm = RealmController.with(this).getRealm();
       // rChannels  = RealmController.with(this).getChannels();
        AutoFitGridLayoutManager layoutManager = new AutoFitGridLayoutManager(getActivity(), 300);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),3));
        getChannelsFromSeverToDatabase();

        return view;
    }


    private void getChannelsFromSeverToDatabase() {

        OkHttpClient client = new OkHttpClient();
        client.setConnectTimeout(30, TimeUnit.SECONDS);
        client.setReadTimeout(30, TimeUnit.SECONDS);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Config.url)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();


        IRetrofit service = retrofit.create(IRetrofit.class);

        try {

            Call<List<Channel>> call = service.getChannels();
            call.enqueue(new Callback<List<Channel>>() {
                @Override
                public void onResponse(Response<List<Channel>> response, Retrofit retrofit) {


                    if(response.isSuccess()) {
                        //channelAdapter = new ChannelAdapter(rChannels,getActivity());


                        List<Channel>   channels = response.body();

                        channelAdapter = new ChannelAdapter(channels,getActivity());
                        recyclerView.setAdapter(channelAdapter);

                    }else{
                    }


                }

                @Override
                public void onFailure(Throwable t) {


                }
            });
        }catch (Exception e){

        }

    }
}
